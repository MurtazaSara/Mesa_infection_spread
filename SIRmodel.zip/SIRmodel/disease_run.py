
# -*- coding: utf-8 -*-
"""
Created on Wed May  1 13:08:18 2019

@author: dan
"""

from disease_server import server
server.port = 8521 # the default
server.launch()