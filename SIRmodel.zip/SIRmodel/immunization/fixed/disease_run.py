#from disease_server import server
#server.port = 8521 # the default
#server.launch()


from disease_model import *
from numpy import arange
import matplotlib.pyplot as plt
from mesa.batchrunner import BatchRunner

fixed_params= {"width":10,"height":10,
               "initial_infection":0.8,
               "transmissibility":0.5,
               "mean_length_of_disease":10,
               "mean_imm_duration":20,
               "prob_being_immunised":0.05 }

variable_params={ "N":range(2,100,1),"level_of_movement":arange(0.0,1.0,0.1)}

num_iteration=5
num_steps=365

batch_run=BatchRunner(Disease_Model,
                      fixed_parameters=fixed_params,
                      variable_parameters=variable_params,
                      iterations=num_iteration,
                      model_reporters={"Total_infected":calculate_number_infected,"Total_Imm":calculate_number_immunised}
                      )

batch_run.run.all()
run_data=batch_run.get_model_vars_dataframe
plt.scatter(run_data.level_of_movement,run_data.Total_infected)

