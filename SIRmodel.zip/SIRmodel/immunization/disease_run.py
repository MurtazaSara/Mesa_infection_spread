from disease_server import server
server.port = 8521 # the default
server.launch()



