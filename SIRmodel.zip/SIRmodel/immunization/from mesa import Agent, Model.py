from mesa import Agent, Model
from mesa.time import RandomActivation  # random order of agent actions
from mesa.space import MultiGrid  # multiple agents per cell
from mesa.datacollection import DataCollector
import random
import csv

class Person_Agent(Agent):
    # Agent initialization function, possibility of being infected at inception
    def __init__(self, unique_id, model, initial_infection, transmissibility,
                 level_of_movement, mean_length_of_disease, mean_imm_duration,
                 prob_being_immunised):
        super().__init__(unique_id, model)
        self.transmissibility = transmissibility
        self.level_of_movement = level_of_movement
        self.mean_length_of_disease = mean_length_of_disease
        # Store mean immunization duration for random sampling when immunized
        self.mean_imm_duration = mean_imm_duration
        if random.uniform(0, 1) < initial_infection:
            self.infected = True
            self.disease_duration = int(round(random.expovariate(1.0 / self.mean_length_of_disease), 0))
        else:
            self.infected = False
        # Boolean flag to indicate whether the agent is currently immunized
        self.immunised = False
        # Attribute that stores the remaining duration of the agent's immunity
        self.immunisation_duration = 0
        # Attribute that stores the probability of being immunized in each
        # time step, for random sampling
        self.prob_being_immunised = prob_being_immunised

               
    # Agent movement function
    def move(self):
        
        possible_steps = self.model.grid.get_neighborhood(
                self.pos, moore=True, include_center=False)
     
        new_position = random.choice(possible_steps)

        self.model.grid.move_agent(self, new_position)
        
    # Agent infection function
    def infect(self):
        # Get list of agents in this cell
        cellmates = self.model.grid.get_cell_list_contents([self.pos])
        
        # Check if there are other agents here
        if len(cellmates) > 1:
            # for each agent in the cell
            for inhabitant in cellmates:
                # infect the agent with a given probability (transmissibility) if they're not already infected, and not immune    
                if (inhabitant.infected == False and 
                    inhabitant.immunised == False):
                    if random.uniform(0, 1) < self.transmissibility:
                        inhabitant.infected = True
                        inhabitant.disease_duration = int(round(
                                random.expovariate(
                                        1.0 / self.mean_length_of_disease), 0))
                        
    
    def become_immunised(self):
        # Set immunised status to True
        self.immunised = True
        
        # Randomly sample the duration for which the individual will remain
        # immune
        self.immunisation_duration = int(
                random.expovariate(1.0 / self.mean_imm_duration))
                        
    def step(self):
        # Move with given probability
        if random.uniform(0, 1) < self.level_of_movement:
            self.move()
            
        # Begin infecting cellmates (if agent is infected), and update remaining disease duration
        if self.infected == True:
            self.infect()
            # decrement remaining disease duration by one time unit
            self.disease_duration -= 1
            
            # if disease has now run its course, flag that the agent is no longer infected
            if self.disease_duration <= 0:
                self.infected = False
                
        
        if self.immunised == True:
            self.immunisation_duration -= 1
            
            # Check if now no longer immunised
            if self.immunisation_duration <= 0:
                self.immunised = False
        else:
            if random.uniform(0, 1) < self.prob_being_immunised:
                self.become_immunised()

class Disease_Model(Model):
    # ... (remaining code stays the same)

# Function to read unique IDs from CSV file
    def read_tagId_from_csv(file_path):
        unique_ids = []
        with open(file_path, 'r') as file:
            reader = csv.reader(file)
            for row in reader:
            tagId = int(row[0])
            unique_ids.append(tagId)
        return unique_ids[:9]  # Select the first 9 unique IDs

# Example usage
tagIds = read_tagId_from_csv('/Users/sarawatsara/Desktop/7june.csv')
model = Disease_Model(N=9, width=10, height=10, ...)
for unique_id in tagIds:
    a = Person_Agent(unique_id, model, ..., coordinates=coords)
    model.schedule.add(a)
    model.grid.place_agent(a, (0, 0))  # Assign all agents to the same initial position
